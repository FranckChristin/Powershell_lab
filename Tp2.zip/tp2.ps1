﻿# ecrit par : Franck Nguekam 300118196

<#
synopsis:
Fait des essais:
Écrit un script qui est capable de déterminer la taille d'un dossier
Écrit un script qui est capable de tranverser un dossier en affichant les fichiers dans l'ordre ascendante de la propriété LastWriteTime 
Écirt un script qui détecte la présence des paramètres
Une fois que tu as maitrisé les divers aspects du problème, met le tout ensemble dans le fichier

#>

param ([string] $Path=".",
       [int] $Size,
       [int]$Id=444, 
       [switch] $Help)
<#
Path - le chemin à un dossier à analyser
Size - une taille exprimée en Gb
Help - si présent indique d'afficher de l'aide
#>

$size=$size*1GB

# initialiser l'ecriture au journal d'evenement

$lelog = Get-EventLog -LogName "Application" -Source "Tp2Pw" -ErrorAction SilentlyContinue
   if (-not $lelog) {
       New-EventLog -LogName "Application" -Source "Tp2Pw"
   } else {
   Write-Host "continue le log est dejà present dans l'observateur d'évenement `n "
     }
   

if( $Help ) {
    write-host "C`'est un scrpit qui permet de regulariser la taille d`'un dossier en fonction d'une taille preciser au debut `n  "
} 
    
if (Test-Path $Path){
    $lepath= Resolve-Path $Path
    write-host "le dossier `"$lepath`" existe vous pouvez continuer `n "
} else {
        write-eventLog -Logname "Application" -Source "Tp2Pw" -EventId $Id -EntryType "ERROR" -Message "Il y a eu une erreur"
  }
$filename = Split-Path -Path $Path -leaf
Write-Output "dossier courant : $filename"

#dimunier de 50% la taille originale du fichier
 
[int]$CurrentSize=(Get-ChildItem -Path $Path | Measure-Object -Property Length -Sum).Sum
Write-host "le dossier $filename a pour taille :  $CurrentSize , et de taille original $Size(Gb) `n" 
if ($CurrentSize -ge $size) {
    $Midlesize = $size /2
    get-childitem -Path $Path | Sort LastWriteTime  | ForEach-Object { 
        if ($CurrentSize -ge $Midlesize) {
        $CurrentSize = $CurrentSize - $_.Length
        Write-Output $_.FullName >> tp2.log
        } 
    }
} else {
            write-eventLog -Logname "Application" -Source "Tp2Pw" -EventId $Id -EntryType "INFORMATION" -Message "aucun fichier a été supprimé"
  }